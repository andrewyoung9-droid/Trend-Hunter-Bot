
# Trend Hunter Bot (Starter)

A modular pipeline to discover rising hashtags, products, or discussions across social/news sources.
It includes collectors (Reddit, YouTube, RSS), a scoring engine (velocity + novelty), a FastAPI service,
and a lightweight Streamlit dashboard.

## Quickstart

1) Create a virtualenv and install deps:

```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

2) Populate `.env` (copy from `.env.example`) with your API keys (optional to start with RSS only).

3) Initialize the DB and run a quick ingest + score:

```bash
python -m trend_hunter.init_db
python -m trend_hunter.collectors.rss_collect --feeds data/seed_feeds.txt
python -m trend_hunter.scoring.score
```

4) Start API + Dashboard:

```bash
uvicorn trend_hunter.api:app --reload --port 8000
streamlit run dashboard/app.py --server.port 8501
```

Visit:
- API: http://localhost:8000/docs
- Dashboard: http://localhost:8501

## Components

- `collectors/`: Source-specific fetchers (Reddit, YouTube, RSS). Each normalizes to a common schema.
- `scoring/`: Trend detection using time-window counts and z-score vs. trailing baseline (velocity + burstiness).
- `storage/`: SQLAlchemy models and helpers (SQLite by default; swap for Postgres easily).
- `api.py`: FastAPI app to query items, trends, and sources.
- `scheduler.py`: APScheduler jobs for periodic collection/scoring.
- `dashboard/`: Streamlit overview of top trends with filters.

## Ethics & Compliance

- Respect each platform's ToS; prefer official APIs over scraping.
- Allowlists for sources and rate limiting are enabled by default.
- Collect **public** content only; avoid PII. Provide opt-out in code and honor robots.txt for RSS.
- Keep retention short and aggregate where possible.

## Roadmap Ideas

- Add TikTok/Instagram via official/partner APIs or whitelisted vendors.
- Entity linking with spaCy/transformers; deduplicate clusters.
- Novelty via MinHash/SimHash; trend categories via zero-shot classification.
- Webhooks/Slack alerts for threshold exceedance.
