
import streamlit as st
from sqlalchemy import select, desc, create_engine
from sqlalchemy.orm import sessionmaker
from trend_hunter.storage.models import Trend, Item, Source
import os

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./trendhunter.db")
engine = create_engine(DATABASE_URL, future=True)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False, future=True)

st.set_page_config(page_title="Trend Hunter", layout="wide")
st.title("Trend Hunter – Live Trends")

platform = st.selectbox("Platform", ["all","rss","reddit","youtube"], index=0)
limit = st.slider("Top N", 10, 200, 50)

db = SessionLocal()
q = select(Trend).order_by(desc(Trend.score))
if platform != "all":
    q = q.where(Trend.platform==platform)
rows = db.execute(q).scalars().all()

st.subheader("Top Trends")
for r in rows[:limit]:
    with st.expander(f"{r.label} ({r.platform}) – score {r.score:.2f}"):
        # show recent items that contain this label
        iq = select(Item).order_by(desc(Item.published_at))
        items = db.execute(iq).scalars().all()
        count = 0
        for it in items:
            tags = (it.hashtags or "").split(",")
            if r.label in tags:
                st.write(f"- [{it.title}]({it.url}) — {it.author} — {it.published_at}")
                count += 1
                if count>=10:
                    break
