
import re
from typing import List

HASHTAG_RE = re.compile(r"(#\w{2,})")

def extract_hashtags(text: str) -> List[str]:
    return [h.lower() for h in HASHTAG_RE.findall(text or "")]

def clean(text: str) -> str:
    return (text or "").replace("\r"," ").replace("\n"," ").strip()
