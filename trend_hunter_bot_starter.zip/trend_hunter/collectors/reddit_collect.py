
import os, argparse, json, time
from datetime import datetime, timezone
import praw
from sqlalchemy import select
from ..storage.db import SessionLocal
from ..storage.models import Source, Item
from ..utils import extract_hashtags, clean

def upsert_source(db, name: str):
    s = db.execute(select(Source).where(Source.name==name, Source.platform=="reddit")).scalar_one_or_none()
    if not s:
        s = Source(name=name, platform="reddit", meta=json.dumps({}))
        db.add(s); db.commit(); db.refresh(s)
    return s

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--subs", default="technology,privacy,netsec,MachineLearning,sysadmin")
    parser.add_argument("--limit", type=int, default=100)
    args = parser.parse_args()

    reddit = praw.Reddit(
        client_id=os.getenv("REDDIT_CLIENT_ID"),
        client_secret=os.getenv("REDDIT_CLIENT_SECRET"),
        user_agent=os.getenv("REDDIT_USER_AGENT","trend-hunter-bot/0.1")
    )

    db = SessionLocal()
    for sub in [s.strip() for s in args.subs.split(",")]:
        source = upsert_source(db, f"r/{sub}")
        for post in reddit.subreddit(sub).new(limit=args.limit):
            pid = post.id
            published_at = datetime.fromtimestamp(post.created_utc, tz=timezone.utc)
            text = f"{post.title}\n{post.selftext or ''}"
            tags = extract_hashtags(text)
            item = Item(
                source_id=source.id,
                platform_id=str(pid)[:128],
                url=f"https://reddit.com{post.permalink}"[:512],
                author=(str(post.author) if post.author else "")[:128],
                title=clean(post.title)[:512],
                text=clean(post.selftext or ""),
                hashtags=",".join(tags),
                published_at=published_at
            )
            try:
                db.add(item); db.commit()
            except Exception:
                db.rollback()
        time.sleep(0.5)

    print("Reddit collection complete.")

if __name__ == "__main__":
    main()
