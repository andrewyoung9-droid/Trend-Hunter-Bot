
import os, argparse, json, time
from datetime import datetime, timezone
from googleapiclient.discovery import build
from sqlalchemy import select
from ..storage.db import SessionLocal
from ..storage.models import Source, Item
from ..utils import extract_hashtags, clean

def upsert_source(db, name: str):
    s = db.execute(select(Source).where(Source.name==name, Source.platform=="youtube")).scalar_one_or_none()
    if not s:
        s = Source(name=name, platform="youtube", meta=json.dumps({}))
        db.add(s); db.commit(); db.refresh(s)
    return s

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--q", default="privacy security cybersecurity")
    parser.add_argument("--max", type=int, default=25)
    args = parser.parse_args()

    api_key = os.getenv("YOUTUBE_API_KEY")
    yt = build("youtube", "v3", developerKey=api_key)

    db = SessionLocal()
    resp = yt.search().list(q=args.q, part="snippet", type="video", maxResults=min(args.max,50)).execute()
    source = upsert_source(db, "YouTube Search")

    for item in resp.get("items", []):
        vid = item["id"]["videoId"]
        sn = item["snippet"]
        published_at = datetime.fromisoformat(sn["publishedAt"].replace("Z","+00:00")).astimezone(timezone.utc)
        title = sn.get("title","")
        desc = sn.get("description","")
        text = f"{title}\n{desc}"
        tags = extract_hashtags(text)
        obj = Item(
            source_id=source.id,
            platform_id=vid[:128],
            url=f"https://www.youtube.com/watch?v={vid}",
            author=sn.get("channelTitle","")[:128],
            title=clean(title)[:512],
            text=clean(desc),
            hashtags=",".join(tags),
            published_at=published_at
        )
        try:
            db.add(obj); db.commit()
        except Exception:
            db.rollback()
        time.sleep(0.1)

    print("YouTube collection complete.")

if __name__ == "__main__":
    main()
