
import argparse, json, time, feedparser
from datetime import datetime, timezone
from sqlalchemy import select
from ..storage.db import SessionLocal
from ..storage.models import Source, Item
from ..utils import extract_hashtags, clean

def upsert_source(db, name: str):
    s = db.execute(select(Source).where(Source.name==name, Source.platform=="rss")).scalar_one_or_none()
    if not s:
        s = Source(name=name, platform="rss", meta=json.dumps({}))
        db.add(s); db.commit(); db.refresh(s)
    return s

def parse_time(entry):
    try:
        if entry.get("published_parsed"):
            return datetime(*entry.published_parsed[:6], tzinfo=timezone.utc)
    except Exception:
        pass
    return datetime.now(timezone.utc)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--feeds", default="data/seed_feeds.txt")
    args = parser.parse_args()

    db = SessionLocal()

    with open(args.feeds, "r", encoding="utf-8") as fh:
        feeds = [l.strip() for l in fh if l.strip() and not l.startswith("#")]

    for url in feeds:
        try:
            feed = feedparser.parse(url)
            source = upsert_source(db, feed.feed.get("title", url)[:64])
            for e in feed.entries:
                pid = e.get("id") or e.get("guid") or e.get("link")
                if not pid:
                    continue
                published_at = parse_time(e)
                title = e.get("title","")
                summary = e.get("summary","")
                text = f"{title}\n{summary}"
                tags = extract_hashtags(text)
                item = Item(
                    source_id=source.id,
                    platform_id=pid[:128],
                    url=e.get("link","")[:512],
                    author=(e.get("author") or "")[:128],
                    title=clean(title)[:512],
                    text=clean(summary),
                    hashtags=",".join(tags),
                    published_at=published_at
                )
                try:
                    db.add(item); db.commit()
                except Exception:
                    db.rollback()
            time.sleep(0.5)
        except Exception as ex:
            print("Feed error:", url, ex)

    print("RSS collection complete.")

if __name__ == "__main__":
    main()
