
from sqlalchemy.orm import declarative_base, relationship, Mapped, mapped_column
from sqlalchemy import String, Integer, DateTime, Text, Float, ForeignKey, Index, UniqueConstraint
from datetime import datetime

Base = declarative_base()

class Source(Base):
    __tablename__ = "sources"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(64), index=True)
    platform: Mapped[str] = mapped_column(String(32), index=True)  # reddit, youtube, rss, etc.
    meta: Mapped[str] = mapped_column(Text, default="{}")
    __table_args__ = (UniqueConstraint("name", "platform", name="uq_source_name_platform"),)

class Item(Base):
    __tablename__ = "items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    source_id: Mapped[int] = mapped_column(ForeignKey("sources.id", ondelete="CASCADE"), index=True)
    platform_id: Mapped[str] = mapped_column(String(128), index=True)  # e.g., Reddit id, YouTube videoId, RSS GUID
    url: Mapped[str] = mapped_column(String(512))
    author: Mapped[str] = mapped_column(String(128), default="")
    title: Mapped[str] = mapped_column(String(512), default="")
    text: Mapped[str] = mapped_column(Text, default="")
    hashtags: Mapped[str] = mapped_column(Text, default="")  # comma-separated
    published_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    collected_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

    source = relationship("Source")

    __table_args__ = (
        UniqueConstraint("platform_id", "source_id", name="uq_item_platform_source"),
        Index("idx_item_time", "published_at"),
    )

class Score(Base):
    __tablename__ = "scores"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id", ondelete="CASCADE"), index=True)
    metric: Mapped[str] = mapped_column(String(32), index=True)  # 'velocity', 'burst', 'novelty', 'final'
    value: Mapped[float] = mapped_column(Float, default=0.0)
    window_minutes: Mapped[int] = mapped_column(Integer, default=60)
    scored_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

class Trend(Base):
    __tablename__ = "trends"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    label: Mapped[str] = mapped_column(String(256), index=True)  # hashtag or keyphrase
    platform: Mapped[str] = mapped_column(String(32), index=True)
    score: Mapped[float] = mapped_column(Float, default=0.0, index=True)
    sample_item_id: Mapped[int] = mapped_column(Integer, default=0)
    window_minutes: Mapped[int] = mapped_column(Integer, default=60)
    computed_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

    __table_args__ = (Index("idx_trend_label_platform", "label", "platform"),)
