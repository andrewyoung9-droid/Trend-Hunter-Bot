
from .storage.models import Base
from .storage.db import engine

def main():
    Base.metadata.create_all(engine)
    print("DB initialized.")

if __name__ == "__main__":
    main()
