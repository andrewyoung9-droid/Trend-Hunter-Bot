
from datetime import datetime, timedelta, timezone
from collections import Counter, defaultdict
from sqlalchemy import select
from ..storage.db import SessionLocal
from ..storage.models import Item, Trend
from ..utils import extract_hashtags

WINDOW_MINUTES = 180
BASELINE_HOURS = 48
PLATFORMS = ["rss","reddit","youtube"]

def main():
    db = SessionLocal()
    now = datetime.now(timezone.utc)
    window_start = now - timedelta(minutes=WINDOW_MINUTES)
    baseline_start = now - timedelta(hours=BASELINE_HOURS)

    # Count labels in window vs. baseline per platform
    platform_items = defaultdict(list)
    q = db.execute(select(Item).where(Item.published_at >= baseline_start)).scalars().all()
    for it in q:
        platform_items[it.source.platform].append(it)

    for platform in PLATFORMS:
        items = platform_items.get(platform, [])
        window_counts = Counter()
        baseline_counts = Counter()
        for it in items:
            labels = [l for l in (it.hashtags or "").split(",") if l] or extract_hashtags((it.title or "") + " " + (it.text or ""))
            if it.published_at >= window_start:
                window_counts.update(labels)
            baseline_counts.update(labels)

        trends = []
        for label, wc in window_counts.items():
            bc = max(1, baseline_counts[label])  # avoid div by zero
            velocity = wc / (WINDOW_MINUTES/60.0)          # per hour
            lift = wc / bc                                 # burst vs baseline
            score = (velocity * 0.6) + (lift * 0.4)        # simple blend
            trends.append((label, score))

        # persist top N
        trends.sort(key=lambda x: x[1], reverse=True)
        top = trends[:100]
        # clear old platform trends (simple approach)
        db.query(Trend).filter(Trend.platform==platform).delete()
        for label, score in top:
            db.add(Trend(label=label, platform=platform, score=score, window_minutes=WINDOW_MINUTES))
        db.commit()

    print("Scoring complete.")

if __name__ == "__main__":
    main()
