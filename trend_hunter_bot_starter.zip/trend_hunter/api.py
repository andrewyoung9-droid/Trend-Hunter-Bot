
from fastapi import FastAPI, Query
from sqlalchemy import select, desc
from .storage.db import SessionLocal
from .storage.models import Trend, Item, Source

app = FastAPI(title="Trend Hunter Bot API")

@app.get("/trends")
def get_trends(platform: str | None = None, limit: int = 50):
    db = SessionLocal()
    q = select(Trend).order_by(desc(Trend.score))
    if platform:
        q = q.where(Trend.platform==platform)
    rows = db.execute(q).scalars().all()
    return [{
        "label": r.label,
        "platform": r.platform,
        "score": r.score,
        "computed_at": r.computed_at.isoformat(),
    } for r in rows[:limit]]

@app.get("/items")
def get_items(label: str | None = None, limit: int = 100):
    db = SessionLocal()
    q = select(Item).order_by(desc(Item.published_at))
    rows = db.execute(q).scalars().all()
    out = []
    for it in rows:
        if label and (label not in (it.hashtags or "").split(",")):
            continue
        out.append({
            "id": it.id, "source": it.source_id, "url": it.url, "author": it.author,
            "title": it.title, "hashtags": it.hashtags.split(",") if it.hashtags else [],
            "published_at": it.published_at.isoformat()
        })
        if len(out) >= limit:
            break
    return out

@app.get("/sources")
def get_sources():
    db = SessionLocal()
    rows = db.execute(select(Source)).scalars().all()
    return [{"id": s.id, "name": s.name, "platform": s.platform} for s in rows]
