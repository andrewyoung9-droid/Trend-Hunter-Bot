
import os
from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.cron import CronTrigger
from dotenv import load_dotenv
load_dotenv()

def run(cmd):
    os.system(cmd)

sched = BlockingScheduler()

sched.add_job(run, CronTrigger.from_crontab(os.getenv("CRON_RSS","*/15 * * * *")), args=["python -m trend_hunter.collectors.rss_collect --feeds data/seed_feeds.txt"])
sched.add_job(run, CronTrigger.from_crontab(os.getenv("CRON_REDDIT","*/10 * * * *")), args=["python -m trend_hunter.collectors.reddit_collect --subs technology,privacy"])
sched.add_job(run, CronTrigger.from_crontab(os.getenv("CRON_YOUTUBE","*/30 * * * *")), args=["python -m trend_hunter.collectors.youtube_collect --q 'privacy security'"])
sched.add_job(run, CronTrigger.from_crontab(os.getenv("CRON_SCORING","*/20 * * * *")), args=["python -m trend_hunter.scoring.score"])

if __name__ == "__main__":
    print("Starting scheduler... (Ctrl+C to stop)")
    sched.start()
